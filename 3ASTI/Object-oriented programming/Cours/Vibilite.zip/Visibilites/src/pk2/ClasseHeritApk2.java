package pk2;

import pk1.ClasseA;


public class ClasseHeritApk2 extends ClasseA {

		
		/**
		 */
		public ClasseHeritApk2(){
			//			private_attr = "Non";
			// pack_attr = "Non";
			protected_attr = "Oui";
			public_attr = "Oui";
		
		}

}
