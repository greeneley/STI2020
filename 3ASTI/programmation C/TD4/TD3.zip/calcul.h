#ifndef _CALCUL_H
#define _CALCUL_H
struct matrice add_matrice(struct matrice ,struct matrice );
struct matrice multiply_matrice(struct matrice , struct matrice );
#endif
