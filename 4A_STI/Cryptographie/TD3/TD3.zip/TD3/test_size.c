#include <stdio.h>

int main()
{
	printf(" taille short = %d\n", sizeof( short ));
	printf(" taille unsigned short = %d\n", sizeof( unsigned short ));
	printf(" taille int = %d\n", sizeof( int ));
	printf(" taille unsigned int = %d\n", sizeof( unsigned int ));
	printf(" taille long int = %d\n", sizeof( long int ));
	printf(" taille unsigned long int = %d\n", sizeof( unsigned long int ));
	printf(" taille long long int = %d\n", sizeof( long long int ));
	printf(" taille unsigned long long int = %d\n", sizeof( unsigned long long int ));
	return(1);
}
