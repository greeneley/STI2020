package tutorat;

public class MailBox {

}
