package tutorat;

public class Reader {

}
