/**
 * 
 */
package safes;

import valuables.Saphir;

/** 
 * @author pascal
 */
public class NewSaphir {

}
