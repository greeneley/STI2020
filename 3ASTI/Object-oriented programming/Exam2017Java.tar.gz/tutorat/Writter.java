package tutorat;

public class Writter {

}
