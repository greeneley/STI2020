package pk1;


public class ClasseHeritA extends ClasseA {
	
	public ClasseHeritA() {
		// TODO Auto-generated constructor stub
//		private_attr = "Non";
		pack_attr = "Oui";
		protected_attr = "Oui";
		public_attr = "Oui";
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClasseA ca = new ClasseA();
		
//		System.out.println("Private " + ca.private_attr);
		System.out.println("Protected " + ca.protected_attr);
		System.out.println("Package " + ca.protected_attr);
		System.out.println("Public " + ca.public_attr);

	}

}
