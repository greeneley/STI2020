package pk1.pk11;

import pk1.ClasseA;


public class ClasseHeritApk11 extends ClasseA {


	/**
	 */
	public ClasseHeritApk11(){

		//			private_attr = "Non";
		// pack_attr = "Non";
		protected_attr = "Oui";
		public_attr = "Oui";
	}

}
