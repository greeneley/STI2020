import johnArithmetics.MathsUtils;
import junit.framework.TestCase;

public class test2 extends TestCase {

	public void testMathsUtils() {
		fail("Not yet implemented");
		
	}
	public void testJohnBetterPPCM1() {
			assertEquals(0,MathsUtils.johnBetterPPCM(0,0));	
	}
	/*  / by 0  */
	public void testJohnBetterPPCM2() {
			assertEquals(0,MathsUtils.johnBetterPPCM(0,42));
	}
	public void testJohnBetterPPCM3() {	
			assertEquals(0,MathsUtils.johnBetterPPCM(42,0));	
	}
	public void testJohnBetterPPCM4() {
	
			assertEquals(42,MathsUtils.johnBetterPPCM(42,42));
	}
	public void testJohnBetterPPCM5() {
			assertEquals(840,MathsUtils.johnBetterPPCM(60,168));
	}
//	==============================
	public void testJohnFaultyPPCM1() {
		assertEquals(0,MathsUtils.johnFaultyPPCM(0,0));
	}

	public void testJohnFaultyPPCM2() {
		assertEquals(0,MathsUtils.johnFaultyPPCM(0,42));
	}
	public void testJohnFaultyPPCM3() {	
		assertEquals(0,MathsUtils.johnFaultyPPCM(42,0));	
	}
	public void testJohnFaultyPPCM4() {
		assertEquals(42,MathsUtils.johnFaultyPPCM(42,42));
	}
	public void testJohnFaultyPPCM5() {
		assertEquals(840,MathsUtils.johnFaultyPPCM(60,168));
	}		
//	=============================
	public void testJohnCorrectPPCM1() {
		assertEquals(0,MathsUtils.johnCorrectPPCM(0,0));	
	}

	public void testJohnCorrectPPCM2() {
		assertEquals(0,MathsUtils.johnCorrectPPCM(0,42));
	}
	public void testJohnCorrectPPCM3() {	
		assertEquals(0,MathsUtils.johnCorrectPPCM(42,0));	
	}
	public void testJohnCorrectPPCM4() {
		assertEquals(42,MathsUtils.johnCorrectPPCM(42,42));
	}
	public void testJohnCorrectPPCM5() {
		assertEquals(840,MathsUtils.johnCorrectPPCM(60,168));
	}		
//	=============================
	public void testJohnBetterPPCM() {
		assertEquals(0,MathsUtils.johnBetterPPCM(0,0));
		assertEquals(0,MathsUtils.johnBetterPPCM(42,0));
		assertEquals(0,MathsUtils.johnBetterPPCM(0,42));
		assertEquals(42,MathsUtils.johnBetterPPCM(42,42));
		assertEquals(840,MathsUtils.johnBetterPPCM(60,168));
	}

	public void testJohnFaultyPPCM() {
		assertEquals(0,MathsUtils.johnFaultyPPCM(0,0));
		assertEquals(0,MathsUtils.johnFaultyPPCM(42,0));
		assertEquals(0,MathsUtils.johnFaultyPPCM(0,42));
		assertEquals(42,MathsUtils.johnFaultyPPCM(42,42));
		assertEquals(840,MathsUtils.johnFaultyPPCM(60,168));
	}

	public void testJohnCorrectPPCM() {
		assertEquals(0,MathsUtils.johnCorrectPPCM(0,0));
		assertEquals(0,MathsUtils.johnCorrectPPCM(42,0));
		assertEquals(0,MathsUtils.johnCorrectPPCM(0,42));
		assertEquals(42,MathsUtils.johnCorrectPPCM(42,42));
		assertEquals(840,MathsUtils.johnCorrectPPCM(60,168));
	}

	public void testObject() {
		fail("Not yet implemented");
	}

	public void testGetClass() {
		fail("Not yet implemented");
	}

	public void testHashCode() {
		fail("Not yet implemented");
	}

	public void testEquals() {
		fail("Not yet implemented");
	}

	public void testClone() {
		fail("Not yet implemented");
	}

	public void testToString() {
		fail("Not yet implemented");
	}

	public void testNotify() {
		fail("Not yet implemented");
	}

	public void testNotifyAll() {
		fail("Not yet implemented");
	}

	public void testWaitLong() {
		fail("Not yet implemented");
	}

	public void testWaitLongInt() {
		fail("Not yet implemented");
	}

	public void testWait() {
		fail("Not yet implemented");
	}

	public void testFinalize() {
		fail("Not yet implemented");
	}
//	public void testJohnBetterPCCM() {
//			MathsUtils.johnBetterPPCM(0,0);
//	}
}