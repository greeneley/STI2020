package pk1;

import java.util.HashMap;
import java.util.Map;

public class Catalogue {
	
	private Map<String,String> description;
	private Map<String, Double> prix;
	
	public Catalogue(){
		description = new HashMap<String, String>();
		prix = new HashMap<String, Double>();
		
	}

	public void inserer(String ref, String desc, double prix){
		
		this.description.put(ref, desc);
		this.prix.put(ref, prix);
	}
	
	public String getDescription(String ref){
		return description.get(ref);
	}
	
	public Double getPrix(String ref){
		return prix.get(ref);
	}
	
	public void liquidation(){
		for(String ref: prix.keySet()){
			//System.out.println(description.get(ref) + ": " + prix.get(ref));
			prix.put(ref, prix.get(ref)/2);
		}
		
	}
}
