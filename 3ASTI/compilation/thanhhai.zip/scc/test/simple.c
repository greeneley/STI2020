int p;
int q;
input(p);
print(p+1);
