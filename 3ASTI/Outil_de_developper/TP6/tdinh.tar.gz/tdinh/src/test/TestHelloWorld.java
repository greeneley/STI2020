package test;

import org.jmb.HelloWorld;

import junit.framework.TestCase;

public class TestHelloWorld extends TestCase {

	public void testGetName() {
		HelloWorld a = new HelloWorld();
		String setted = "setted";
		a.setName(setted);
		assertEquals(a.getName(), setted);
	}

	public void testGetMessage() {
		fail("Not yet implemented");
	}

	public void testSetName() {
		fail("Not yet implemented");
	}
	public void testNothing() {
    }

    public void testWillAlwaysFail() {
        fail("An error message");
    }

}
