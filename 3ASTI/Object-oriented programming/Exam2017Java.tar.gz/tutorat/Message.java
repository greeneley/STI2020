package tutorat;

public class Message {

}
