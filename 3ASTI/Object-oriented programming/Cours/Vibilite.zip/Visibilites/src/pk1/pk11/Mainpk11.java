package pk1.pk11;

import pk1.ClasseA;


public class Mainpk11 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

			
			ClasseA ca = new ClasseA();
			
//			System.out.println("Private " + ca.private_attr);
//			System.out.println("Protected " + ca.protected_attr);
//			System.out.println("Package " + ca.protected_attr);
			System.out.println("Public " + ca.public_attr);

		

	}

}
