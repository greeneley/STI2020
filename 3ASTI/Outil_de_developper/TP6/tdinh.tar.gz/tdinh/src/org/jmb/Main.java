package org.jmb;
public class Main {
	public static void main(String[] args) {
	      HelloWorld h = new HelloWorld();
	      h.setName("JMB");
	      System.out.println(h.getMessage());
	}
}