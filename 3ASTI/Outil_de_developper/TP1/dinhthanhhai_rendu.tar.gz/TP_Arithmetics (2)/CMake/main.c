/**
 * \file main.c
 * \brief main file for lcm project. Contains one main that calcultes gcd.
 * \author L.Bobelin
 * \version 1.0
 * \date 2018, March, 1rst
 *
 */

#include <string.h>
#include <stdio.h>
#include "lcm.h"
int main()
{
        printf("lcm(23, 21) = %d\n", lcm(23, 21));
        return 0;
}
