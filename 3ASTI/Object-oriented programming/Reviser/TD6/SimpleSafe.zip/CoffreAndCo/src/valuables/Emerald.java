/**
 * 
 */
package valuables;

/** 
 * @author pascal
 */
public class Emerald extends Gemstone {

	public Emerald( double volume) {
		super( volume);
		// TODO Auto-generated constructor stub
	}


	/**
	 */
	public void expertize(){
		value = volume * volume;
		
	}

}
