package pk1;


public class ClasseA {

	/** 
	 * @uml.property name="private_attr"
	 */
	private String private_attr;
	/**
	 * @uml.property  name="pack_attr"
	 */
	String pack_attr;
	/**
	 * @uml.property  name="protected_attr"
	 */
	protected String protected_attr;
	/**
	 * @uml.property  name="public_attr"
	 */
	public String public_attr;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ClasseA ca = new ClasseA();
		
		System.out.println("Private " + ca.private_attr);
		System.out.println("Protected " + ca.protected_attr);
		System.out.println("Package " + ca.protected_attr);
		System.out.println("Public " + ca.public_attr);

	}

}
