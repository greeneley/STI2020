package pk1;

import java.util.HashMap;
import java.util.Map;

public class TestObject {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		Object o1 = new Object();
		Object o2 = new Object();
		Object o3 = o1;
		
		System.out.println(o1.toString());
		System.out.println(o2);
		System.out.println(o3);
		
		if (o1 == o3){
			System.out.println("Même chose");
		}
		else
			System.out.println("Différents");
	*/
		
		Pair p1 = new Pair(10, 15);
		Pair p2 = new Pair(10, 15);
		
		// Attention : toString de Object retourne le nom de la classe suivi du hashcode de
		// l'objet
		// Si on surcharge la méthode deux objets ayant les cararactéristiques identiques ont le 
		// même hash.
		// Le hashcode est utilisé dans les HashMaps!
		System.out.println(p1);
		System.out.println(p2);
		
		
		
		// Est-ce que ce sont les mêmes objets
		if (p1 == p2){
			System.out.println("Même chose");
		}
		else
			System.out.println("Différents");
	
		// Est-ce qu'ils sont égaux (nuance subtile avec le précédent)
		if (p1.equals(p2)){
			System.out.println("Même chose");
		}
		else
			System.out.println("Différents");
		
		/*
		GenericPair<Integer, Integer> pii = new GenericPair<Integer, Integer>(10, 15);
//		GenericPair<Integer, Integer> pii2 = pii.clone();
		
		System.out.println(pii);
		
		if (p1.equals(pii)){
			System.out.println("Même chose");
		}
		else
			System.out.println("Différents");
		*/
		
		/*
		Catalogue leMagasin = new Catalogue();
		
		leMagasin.inserer("AA001","Chaussettes Vertes", 3.0);
		leMagasin.inserer("AA002","Chaussettes Bleues", 4.0);
		leMagasin.inserer("AA003","Chaussettes à pois", 5.0);
		leMagasin.inserer("AA001","Chaussettes Vertes", 4.0);
		
		System.out.println(leMagasin.getDescription("AA001"));
		System.out.println(leMagasin.getPrix("AA001"));
		
		leMagasin.liquidation();
		System.out.println(leMagasin.getDescription("AA003"));
		System.out.println(leMagasin.getPrix("AA003"));
		*/
		
		Map<Pair, Integer> mpi = new HashMap<Pair, Integer>();
		mpi.put(p1, 21);
		mpi.put(p2, 3);
		
		System.out.println(mpi.size());
		
		
	}

}
