int f(int p, int q)
{
 return p + q;
}

void main()
{
  int x;
  int y;
  x = f(x, x + y);
}
