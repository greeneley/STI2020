#ifndef H_LCM
#define H_LCM

int lcm(int u, int v);
 
#endif
