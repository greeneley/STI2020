/**
 * 
 */
package safes;

/** 
 * @author pascal
 */
public interface ToSale {

	/** 
	 * @return  Returns the value.
	 * @uml.property  name="value" readOnly="true"
	 */
	public double getValue();

}
