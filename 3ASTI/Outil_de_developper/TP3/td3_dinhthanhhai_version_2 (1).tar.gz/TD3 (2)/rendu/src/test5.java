import static org.junit.Assert.*;
import johnArithmetics.MathsUtils;

import org.junit.Test;


public class test5 {
	@Test
	public void testJohnBetterPPCM1() {
		try{
		assertEquals(0,MathsUtils.johnBetterPPCM(0,0));
		} catch (Exception e) {
				e.printStackTrace();
			}
	}
	@Test
	public void testJohnBetterPPCM2() {
		try{	
		assertEquals(0,MathsUtils.johnBetterPPCM(0,42));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnBetterPPCM3() {	
			try{
				assertEquals(0,MathsUtils.johnBetterPPCM(42,0));	
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	@Test
	public void testJohnBetterPPCM4() {
			try{
			assertEquals(42,MathsUtils.johnBetterPPCM(42,42));
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	@Test
	public void testJohnBetterPPCM5() {
			try{
				assertEquals(840,MathsUtils.johnBetterPPCM(60,168));
			}catch (Exception e) {
				e.printStackTrace();
			}
	}
//	==============================
	@Test
	public void testJohnFaultyPPCM1() {
		try{
			assertEquals(0,MathsUtils.johnFaultyPPCM(0,0));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnFaultyPPCM2() {
		try{
			assertEquals(0,MathsUtils.johnFaultyPPCM(0,42));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnFaultyPPCM3() {	
		try{
			assertEquals(0,MathsUtils.johnFaultyPPCM(42,0));	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnFaultyPPCM4() {
		try{
			assertEquals(42,MathsUtils.johnFaultyPPCM(42,42));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnFaultyPPCM5() {
		try{
			assertEquals(840,MathsUtils.johnFaultyPPCM(60,168));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}		
//	=============================
	@Test
	public void testJohnCorrectPPCM1() {
		try{
			assertEquals(0,MathsUtils.johnCorrectPPCM(0,0));	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnCorrectPPCM2() {
		try{
			assertEquals(0,MathsUtils.johnCorrectPPCM(0,42));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnCorrectPPCM3() {	
		try{
			assertEquals(0,MathsUtils.johnCorrectPPCM(42,0));	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnCorrectPPCM4() {
		try{
			assertEquals(42,MathsUtils.johnCorrectPPCM(42,42));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testJohnCorrectPPCM5() {
		try{
			assertEquals(840,MathsUtils.johnCorrectPPCM(60,168));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}		
//	=============================
//	@Test
//	public void testJohnBetterPPCM() {
//		try{
//			assertEquals(0,MathsUtils.johnBetterPPCM(0,0));
//		assertEquals(0,MathsUtils.johnBetterPPCM(42,0));
//		assertEquals(0,MathsUtils.johnBetterPPCM(0,42));
//		assertEquals(42,MathsUtils.johnBetterPPCM(42,42));
//		assertEquals(840,MathsUtils.johnBetterPPCM(60,168));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	@Test
//	public void testJohnFaultyPPCM() {
//		try{
//			assertEquals(0,MathsUtils.johnFaultyPPCM(0,0));
//		assertEquals(0,MathsUtils.johnFaultyPPCM(42,0));
//		assertEquals(0,MathsUtils.johnFaultyPPCM(0,42));
//		assertEquals(42,MathsUtils.johnFaultyPPCM(42,42));
//		assertEquals(840,MathsUtils.johnFaultyPPCM(60,168));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//	@Test
//	public void testJohnCorrectPPCM() {
//		try{
//			assertEquals(0,MathsUtils.johnCorrectPPCM(0,0));
//		assertEquals(0,MathsUtils.johnCorrectPPCM(42,0));
//		assertEquals(0,MathsUtils.johnCorrectPPCM(0,42));
//		assertEquals(42,MathsUtils.johnCorrectPPCM(42,42));
//		assertEquals(840,MathsUtils.johnCorrectPPCM(60,168));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	@Test
	public void testObject() {
		fail("Not yet implemented");
	}

	public void testGetClass() {
		fail("Not yet implemented");
	}

	public void testHashCode() {
		fail("Not yet implemented");
	}

	public void testEquals() {
		fail("Not yet implemented");
	}

	public void testClone() {
		fail("Not yet implemented");
	}

	public void testToString() {
		fail("Not yet implemented");
	}

	public void testNotify() {
		fail("Not yet implemented");
	}

	public void testNotifyAll() {
		fail("Not yet implemented");
	}

	public void testWaitLong() {
		fail("Not yet implemented");
	}

	public void testWaitLongInt() {
		fail("Not yet implemented");
	}

	public void testWait() {
		fail("Not yet implemented");
	}

	public void testFinalize() {
		fail("Not yet implemented");
	}

}
