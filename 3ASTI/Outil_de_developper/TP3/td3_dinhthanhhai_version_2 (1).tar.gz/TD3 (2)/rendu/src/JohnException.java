
public class JohnException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
