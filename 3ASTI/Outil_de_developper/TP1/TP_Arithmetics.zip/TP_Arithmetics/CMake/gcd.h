#ifndef H_GCD
#define H_GCD
 
int gcd_iter(int u, int v);
int gcd(int u, int v);
int gcd_bin(int u, int v)
 
#endif
